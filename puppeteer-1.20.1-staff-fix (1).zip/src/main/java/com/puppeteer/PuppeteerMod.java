package com.puppeteer;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;

public final class PuppeteerMod implements ModInitializer {
    public static final String MOD_ID = "puppeteer";

    @Override
    public void onInitialize() {
        PuppeteerItems.initialize();

        // Give each joining player a wand if they do not already carry one.
        // The message is sent in chat (not the action bar) so it is easy to notice.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                giveWandIfMissing(handler.player));

        // Fallback for players who lose the wand or want to retrieve it manually.
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(Commands.literal("puppeteer")
                        .then(Commands.literal("wand").executes(context -> {
                            ServerPlayer player = context.getSource().getPlayerOrException();
                            // This explicit recovery command always gives a fresh wand,
                            // even if the player already owns one but cannot find it.
                            giveWand(player);
                            return 1;
                        }))
                        .then(Commands.literal("help").executes(context -> {
                            ServerPlayer player = context.getSource().getPlayerOrException();
                            PuppeteerControl.message(player,
                                    "Wand item ID: puppeteer:puppeteer_wand. Use /puppeteer wand to get one. " +
                                    "Right-click a mob to bind/release it; right-click air to cycle orders; " +
                                    "sneak + right-click air to release all.");
                            return 1;
                        }))));

        UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (!player.getItemInHand(hand).is(PuppeteerItems.PUPPETEER_WAND)) {
                return InteractionResult.PASS;
            }

            if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
                if (entity instanceof Mob mob) {
                    PuppeteerControl.togglePuppet(serverPlayer, mob);
                } else {
                    PuppeteerControl.message(serverPlayer, "That entity can't be puppeteered.");
                }
            }

            // Consume the interaction on both sides so the mob's normal interaction
            // (mounting, trading, opening a menu, etc.) doesn't also happen.
            return InteractionResult.SUCCESS;
        });

        ServerTickEvents.END_SERVER_TICK.register(PuppeteerControl::tick);
    }

    private static void giveWandIfMissing(ServerPlayer player) {
        boolean alreadyHasWand = player.getInventory().items.stream()
                .anyMatch(stack -> stack.is(PuppeteerItems.PUPPETEER_WAND))
                || player.getInventory().offhand.stream()
                .anyMatch(stack -> stack.is(PuppeteerItems.PUPPETEER_WAND));

        if (alreadyHasWand) {
            return;
        }
        giveWand(player);
    }

    private static void giveWand(ServerPlayer player) {
        ItemStack wand = new ItemStack(PuppeteerItems.PUPPETEER_WAND);
        if (!player.getInventory().add(wand)) {
            player.drop(wand, false);
        }
        PuppeteerControl.message(player,
                "You received Puppeteer's Wand. If you cannot see it, check your inventory or use /give @s " +
                "puppeteer:puppeteer_wand. Right-click a mob to bind it; right-click air to change orders.");
    }

}
