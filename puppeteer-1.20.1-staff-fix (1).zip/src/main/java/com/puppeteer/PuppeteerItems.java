package com.puppeteer;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.core.registries.BuiltInRegistries;

public final class PuppeteerItems {
    public static final Item PUPPETEER_WAND = register(
            "puppeteer_wand",
            new PuppeteerWand(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC))
    );

    private PuppeteerItems() {}

    private static <T extends Item> T register(String name, T item) {
        return Registry.register(
                BuiltInRegistries.ITEM,
                new ResourceLocation(PuppeteerMod.MOD_ID, name),
                item
        );
    }

    public static void initialize() {
        // Register in the usual tools tab and the combat tab, making it easy to find.
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(PUPPETEER_WAND));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT)
                .register(entries -> entries.accept(PUPPETEER_WAND));
    }
}
