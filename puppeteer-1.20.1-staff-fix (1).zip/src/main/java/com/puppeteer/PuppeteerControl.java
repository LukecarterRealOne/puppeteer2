package com.puppeteer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Server-side command state for mobs recruited with the Puppeteer Wand. */
public final class PuppeteerControl {
    private static final int MAX_PUPPETS_PER_PLAYER = 32;
    private static final double FOLLOW_STOP_DISTANCE_SQUARED = 9.0;
    private static final long ROAM_INTERVAL_TICKS = 80;
    private static final double ROAM_RADIUS = 6.0;

    private enum Order {
        FOLLOW("Follow Me"),
        STAY("Stay"),
        ROAM_NEARBY("Roam Nearby"),
        ATTACK_NEARBY("Attack Nearby Hostiles");

        private final String label;
        Order(String label) { this.label = label; }
        public String label() { return label; }
    }

    private record PuppetRecord(UUID ownerId) {}

    // Insertion order is kept so the recruited group is predictable when iterating.
    private static final Map<UUID, PuppetRecord> CONTROLLED = new LinkedHashMap<>();
    private static final Map<UUID, LinkedHashSet<UUID>> BY_OWNER = new HashMap<>();
    private static final Map<UUID, Order> ORDERS = new HashMap<>();
    private static final Map<UUID, Long> NEXT_ROAM_TICK = new HashMap<>();

    private PuppeteerControl() {}

    public static void togglePuppet(ServerPlayer player, Mob mob) {
        UUID playerId = player.getUUID();
        UUID mobId = mob.getUUID();
        PuppetRecord existing = CONTROLLED.get(mobId);

        if (existing != null) {
            if (existing.ownerId().equals(playerId)) {
                forgetPuppet(mobId);
                message(player, "Released " + mob.getType().getDescription().getString() + ".");
            } else {
                message(player, "That mob is already bound to another puppeteer.");
            }
            return;
        }

        Set<UUID> owned = BY_OWNER.computeIfAbsent(playerId, ignored -> new LinkedHashSet<>());
        if (owned.size() >= MAX_PUPPETS_PER_PLAYER) {
            message(player, "Your puppet group is full (" + MAX_PUPPETS_PER_PLAYER + "). Release one first.");
            return;
        }

        if (!mob.isAlive() || mob.isRemoved()) {
            message(player, "That mob can't be recruited right now.");
            return;
        }

        CONTROLLED.put(mobId, new PuppetRecord(playerId));
        owned.add(mobId);
        ORDERS.putIfAbsent(playerId, Order.FOLLOW);
        message(player, "Bound " + mob.getType().getDescription().getString() + " · puppets: " + owned.size());
    }

    public static void cycleOrder(ServerPlayer player) {
        UUID ownerId = player.getUUID();
        Order[] values = Order.values();
        Order current = ORDERS.getOrDefault(ownerId, Order.FOLLOW);
        Order next = values[(current.ordinal() + 1) % values.length];
        ORDERS.put(ownerId, next);
        message(player, "Puppeteer order: " + next.label() + " · group size: " + BY_OWNER.getOrDefault(ownerId, new LinkedHashSet<>()).size());
    }

    public static void releaseAll(ServerPlayer player) {
        UUID ownerId = player.getUUID();
        Set<UUID> owned = BY_OWNER.get(ownerId);
        int released = owned == null ? 0 : owned.size();
        if (owned != null) {
            for (UUID mobId : new ArrayList<>(owned)) {
                forgetPuppet(mobId);
            }
        }
        ORDERS.put(ownerId, Order.FOLLOW);
        message(player, "Released all puppets (" + released + "). Order reset to Follow Me.");
    }

    public static void message(ServerPlayer player, String text) {
        player.displayClientMessage(Component.literal("[Puppeteer] " + text), true);
    }

    public static void tick(MinecraftServer server) {
        // Iterate over a snapshot because dead/unloaded entities may be removed as we go.
        for (Map.Entry<UUID, PuppetRecord> entry : new ArrayList<>(CONTROLLED.entrySet())) {
            UUID mobId = entry.getKey();
            UUID ownerId = entry.getValue().ownerId();
            ServerPlayer owner = server.getPlayerList().getPlayer(ownerId);
            Entity found = findEntity(server, mobId);

            if (owner == null || !(found instanceof Mob mob) || !mob.isAlive() || mob.isRemoved()) {
                forgetPuppet(mobId);
                continue;
            }

            // Dimension-crossing follow paths are not supported by vanilla navigation.
            if (mob.level() != owner.level()) {
                mob.setTarget(null);
                mob.getNavigation().stop();
                continue;
            }

            if (!(mob.level() instanceof ServerLevel serverLevel)) {
                continue;
            }

            Order order = ORDERS.getOrDefault(ownerId, Order.FOLLOW);
            switch (order) {
                case FOLLOW -> follow(mob, owner);
                case STAY -> stay(mob);
                case ROAM_NEARBY -> roamNearby(serverLevel, mob, owner);
                case ATTACK_NEARBY -> attackNearby(serverLevel, mob, owner);
            }
        }

        // Clear stale roam timers so released mobs do not accumulate state.
        NEXT_ROAM_TICK.keySet().removeIf(id -> !CONTROLLED.containsKey(id));
    }

    private static void follow(Mob mob, ServerPlayer owner) {
        mob.setTarget(null);
        if (mob.distanceToSqr(owner) > FOLLOW_STOP_DISTANCE_SQUARED) {
            mob.getNavigation().moveTo(owner, 1.15);
        } else {
            mob.getNavigation().stop();
        }
    }

    private static void stay(Mob mob) {
        mob.setTarget(null);
        mob.getNavigation().stop();
        // Zero velocity each server tick makes this a firm hold-position order while
        // leaving the entity's AI enabled for future commands.
        mob.setDeltaMovement(Vec3.ZERO);
    }

    private static void roamNearby(ServerLevel level, Mob mob, ServerPlayer owner) {
        mob.setTarget(null);
        long now = level.getGameTime();
        long next = NEXT_ROAM_TICK.getOrDefault(mob.getUUID(), Long.MIN_VALUE / 2);
        if (now < next) {
            return;
        }

        // Give each mob a small, different destination around its owner. Destinations
        // are refreshed infrequently so navigation isn't constantly interrupted.
        double angle = level.random.nextDouble() * Math.PI * 2.0;
        double radius = Math.sqrt(level.random.nextDouble()) * ROAM_RADIUS;
        double x = owner.getX() + Math.cos(angle) * radius;
        double z = owner.getZ() + Math.sin(angle) * radius;
        mob.getNavigation().moveTo(x, owner.getY(), z, 0.9);
        NEXT_ROAM_TICK.put(mob.getUUID(), now + ROAM_INTERVAL_TICKS);
    }


    private static void attackNearby(ServerLevel level, Mob mob, ServerPlayer owner) {
        // Only target hostile entities. Players and all recruited puppets are excluded,
        // so the group does not turn on its owner or on itself.
        LivingEntity target = level.getEntitiesOfClass(
                        LivingEntity.class,
                        mob.getBoundingBox().inflate(16.0),
                        candidate -> candidate instanceof Enemy
                                && candidate.isAlive()
                                && !(candidate instanceof Player)
                                && (!(candidate instanceof Mob other) || !CONTROLLED.containsKey(other.getUUID()))
                                && mob.canAttack(candidate))
                .stream()
                .min(Comparator.comparingDouble(mob::distanceToSqr))
                .orElse(null);

        if (target == null) {
            mob.setTarget(null);
            mob.getNavigation().stop();
            return;
        }

        // Native combat goals handle the actual attack; this gives them a target and
        // encourages navigation toward it. Passive mobs without combat goals may not attack.
        mob.setTarget(target);
        mob.getNavigation().moveTo(target, 1.15);
    }

    private static Entity findEntity(MinecraftServer server, UUID id) {
        for (ServerLevel level : server.getAllLevels()) {
            Entity found = level.getEntity(id);
            if (found != null) return found;
        }
        return null;
    }

    private static void forgetPuppet(UUID mobId) {
        PuppetRecord record = CONTROLLED.remove(mobId);
        NEXT_ROAM_TICK.remove(mobId);
        if (record == null) return;

        Set<UUID> owned = BY_OWNER.get(record.ownerId());
        if (owned != null) {
            owned.remove(mobId);
            if (owned.isEmpty()) {
                BY_OWNER.remove(record.ownerId());
            }
        }
    }
}
