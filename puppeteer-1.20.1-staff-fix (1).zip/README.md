# Puppeteer — Fabric mod for Minecraft 1.20.1

Puppeteer adds a magic wand that recruits existing Minecraft `Mob` entities into a group and gives that group simple orders. Built for **Minecraft Java Edition 1.20.1**, **Fabric**, and **Java 17**.

## Getting the wand

This build automatically gives players a **Puppeteer's Wand** when they join if they do not already have one. The message is shown in chat. If it is missing, use:

```mcfunction
/puppeteer wand
```

For a direct registry test, run `/give @s puppeteer:puppeteer_wand`. If Minecraft says the item is unknown, the installed JAR is outdated or the mod failed to register the item. `/puppeteer help` prints the controls. The wand appears in both the Tools & Utilities and Combat creative tabs, and can be crafted from two sticks and an amethyst shard.

**This mod does not automatically spawn mobs.** Find or spawn mobs normally, then right-click them while holding the wand to recruit them.

## Controls

- **Right-click a mob with the wand:** recruit it. Right-click a mob you own again to release it.
- **Right-click air:** cycle the current group order:
  1. **Follow Me** — recruited mobs path toward you.
  2. **Stay** — recruited mobs stop navigating and hold position.
  3. **Roam Nearby** — recruited mobs wander around you.
  4. **Attack Nearby Hostiles** — recruited mobs target nearby hostile entities their native AI can attack; players and recruited puppets are excluded.
- **Sneak + right-click air:** release all recruited mobs and reset the order.
- Up to 32 recruited mobs per player.

## Build locally

Requirements: JDK 17 and Gradle 8.7.

```bash
gradle --no-daemon clean build
```

The remapped mod JAR will be in `build/libs/`.

## GitHub Actions build

The workflow is `.github/workflows/build.yml`. Recommended: extract this ZIP into your repository root and commit `build.gradle`, `settings.gradle`, `gradle.properties`, `src/`, and `.github/workflows/build.yml`. The workflow builds on push, pull request, or manual dispatch. After a successful run, download the `puppeteer-minecraft-1.20.1` artifact from the Actions run.

## Troubleshooting: mod loads but no wand appears

1. Make sure you installed the **new JAR artifact** from the latest successful GitHub Actions run, not the source ZIP, `-sources.jar`, or older JAR.
2. Enter a world and check chat for the join message.
3. Run `/puppeteer wand`; this command always gives a new wand.
4. Try `/give @s puppeteer:puppeteer_wand`. If the item identifier is unknown, remove old Puppeteer JARs and install the newest artifact. Keep only one Puppeteer JAR in `mods`.
5. Search both the Tools & Utilities and Combat creative tabs, or search the creative inventory for “Puppeteer's Wand”.

## Notes

- Install this common/server mod in the Fabric profile used by the world. For dedicated multiplayer servers, the server must have the mod as well.
- It works with vanilla-style `Mob` subclasses, including many modded mobs. Custom entities can override or ignore vanilla navigation/targeting behavior.
- Attack Nearby Hostiles relies on each mob's existing combat AI. Passive creatures without attack goals generally cannot be made to fight by simply assigning a target.
- This source project has not been compiled or tested in-game in this environment. Run the GitHub Actions build to verify the JAR before using it.
